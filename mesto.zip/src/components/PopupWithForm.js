import Popup from "./Popup.js";

export default class PopupWithForm extends Popup {
    constructor({
        popupSelector,
        handleFormSubmit,
    }) {
        super(popupSelector);
        this._handleFormSubmit = handleFormSubmit;
        this._popupForm = this._popup.querySelector('.popup__form');
        this._popupButtonSubmit = this._popup.querySelector('.popup__button-save');
    }
    open(element) {
        super.open();
        this._element = element;
    }

    getSubmitBottonText() {
        return this._popupButtonSubmit.textContent;
    }

    setLoadingText(txt) {
        this._popupButtonSubmit.textContent = txt;
    }

    setEventListeners() {
        super.setEventListeners();
        this._popupForm.addEventListener('submit', (evt) => {
            evt.preventDefault();
            this._handleFormSubmit(this._element);
        });
    }
}